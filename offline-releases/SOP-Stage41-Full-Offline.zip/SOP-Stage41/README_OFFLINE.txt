SOP-generanjr Stage41 / portable offline archive

1. Unzip the whole package (do not preview index.html inside ZIP).
2. Open index.html in Chrome/Edge from the extracted SOP-Stage41 folder.
3. Open the architecture explorer or standalone constructor from the home page.
4. Source links open local HTML viewers with numbered lines; raw source files are adjacent under source/.
5. The owner's private AI proxy endpoint is removed from this archive; AI requests are unavailable.
6. LikeC4 and Archify editable source definitions are in diagrams/.
