SOP-generanjr Stage41 / portable offline archive

1. Unzip the whole package (do not preview index.html inside ZIP).
2. Open index.html in Chrome/Edge from the extracted SOP-Stage41 folder.
3. Open the unified two-mode map or standalone constructor from the home page.
4. Source links open local HTML viewers with numbered lines; raw source files are adjacent under source/.
5. The owner's private AI proxy endpoint is removed from this archive; AI requests are unavailable.
6. LikeC4 and Archify editable source definitions are in diagrams/.
7. Click a graph node to see explanatory text, interactions, AI scenarios and verified source links.
